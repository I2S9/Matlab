%La matrice note contient toutes les notes des chaque �l�ve dans chaque mati�re
note = [4.5 7 12 3.5 14.5 16 12 12 8 9.2;
        3 7.2 16 18 5.5 7 9.5 4.5 12 13;
		11 17 14 15 14 13 18 19 17 15;
        12 10 9 7.5 6 8.5 12 14 13 12];
    
nom = {'Eric','Sarah','Andrew','Omar','Marwa','Alex','John','Mahdi','Laurent','Clemence'};
matiere = {'Maths','Francais','Art', 'Histoire'};
ponderation = [3 2 1 2];


